# <%= bluemix.name || spec.appname -%>

A generated Bluemix application

[![](https://img.shields.io/badge/bluemix-powered-blue.svg)](https://bluemix.net)

## Run locally as Node.js application
```bash
npm install
npm test
npm start
```